export class Brand{
  name?:string;
}

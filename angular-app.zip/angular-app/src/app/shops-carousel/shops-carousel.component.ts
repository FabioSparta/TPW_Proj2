import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shops-carousel',
  templateUrl: './shops-carousel.component.html',
  styleUrls: ['./shops-carousel.component.css']
})
export class ShopsCarouselComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

export class Category{
    name?: string;
    totDevices?:number;
    image?:string;
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shops',
  templateUrl: '../shops/shops.component.html',
  styleUrls: ['../shops/shops.component.css']
})
export class ShopsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

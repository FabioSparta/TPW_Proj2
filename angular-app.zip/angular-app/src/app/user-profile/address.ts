export class Address {
  address: string | undefined;
}
